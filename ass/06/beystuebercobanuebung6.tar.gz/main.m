%Thomas Stueber, Lea Bey, Benjamin Coban

function main

test_state = containers.Map({'A', 'B', 'D', 'X'}, [3, 2,2,2]);
bayes_net(test_state)

end
